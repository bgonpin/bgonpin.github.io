"""
Generador de Estadísticas Completas para Colección MongoDB

Este módulo genera estadísticas matemáticas y categóricas completas a partir de una colección
MongoDB específica. Se conecta a una instancia de MongoDB (local o remota), recupera datos de la colección
especificada, procesa los datos en un DataFrame de pandas, calcula estadísticas detalladas
sobre nombres de archivos, dimensiones de imágenes, fechas, ubicaciones, objetos detectados
y otros campos, muestra los resultados en formato legible con colores (opcionalmente),
y guarda los resultados en un archivo .dat con marca de tiempo.

Dependencias principales:
- pymongo: Para interacción con MongoDB
- pandas: Para manipulación de datos
- colorama: Opcional, para salida coloreada en terminal (instalar con: pip install colorama)

Uso:
    Ejecutar directamente: python generar_estadisticas_mongodb.py
    Asegúrate de configurar las variables de entorno MONGODB_URI, DATABASE_NAME y COLLECTION_NAME

Funciones principales:
- connect_to_mongodb(): Establece conexión con MongoDB
- get_data(): Obtiene todos los documentos de la colección
- convert_to_dataframe(): Convierte datos MongoDB a DataFrame con procesamiento de fechas
- compute_statistics(): Calcula estadísticas exhaustivas sobre los datos
- print_statistics(): Imprime estadísticas estructuradas y coloreadas
- save_to_dat_file(): Guarda estadísticas en archivo .dat con timestamp
- main(): Función principal que coordina todo el flujo
"""

import pymongo
from pymongo import MongoClient
import pandas as pd
from collections import Counter
from datetime import datetime
import statistics
import sys
import os
try:
    import colorama
    from colorama import Fore, Style, init
    colorama_available = True
except ImportError:
    print("colorama no instalado. Instala con: pip install colorama")
    colorama_available = False

def connect_to_mongodb():
    """
    Conecta a la base de datos MongoDB.
    Usa variables de entorno para configuración: MONGODB_URI, DATABASE_NAME, COLLECTION_NAME.
    Si no existen, usa valores por defecto útiles para desarrollo.
    """
    try:
        mongodb_uri = os.getenv('MONGODB_URI', 'mongodb://localhost:27017/')
        database_name = os.getenv('DATABASE_NAME', 'album')
        collection_name = os.getenv('COLLECTION_NAME', 'imagenes_2')

        client = MongoClient(mongodb_uri)
        db = client[database_name]
        collection = db[collection_name]
        print(f"Conectado a MongoDB en {mongodb_uri}, base de datos: {database_name}, colección: {collection_name}")
        return collection
    except Exception as e:
        print(f"Error conectando a MongoDB: {e}")
        sys.exit(1)

def get_data(collection):
    """
    Obtiene todos los documentos de la colección.
    """
    try:
        data = list(collection.find())
        return data
    except Exception as e:
        print(f"Error obteniendo datos: {e}")
        return []

def convert_to_dataframe(data):
    """
    Convierte la lista de documentos a un DataFrame de pandas.
    """
    if not data:
        print("No data found in collection.")
        return pd.DataFrame()

    df = pd.DataFrame(data)

    # Convertir fechas a objetos datetime
    df['fecha_creacion'] = pd.to_datetime(df['fecha_creacion_anio'].astype(str) + '-' +
                                          df['fecha_creacion_mes'].astype(str) + '-' +
                                          df['fecha_creacion_dia'].astype(str) + ' ' +
                                          df['fecha_creacion_hora'].astype(str) + ':' +
                                          df['fecha_creacion_minuto'].astype(str), errors='coerce')

    df['fecha_procesamiento'] = pd.to_datetime(df['fecha_procesamiento_anio'].astype(str) + '-' +
                                               df['fecha_procesamiento_mes'].astype(str) + '-' +
                                               df['fecha_procesamiento_dia'].astype(str) + ' ' +
                                               df['fecha_procesamiento_hora'].astype(str) + ':' +
                                               df['fecha_procesamiento_minuto'].astype(str), errors='coerce')

    return df

def compute_statistics(df):
    """
    Calcula estadísticas matemáticas completas basadas en los datos.
    """
    if df.empty:
        return {}

    stats = {}
    stats['total_registros'] = len(df)

    # Estadísticas sobre nombre (filenames)
    if 'nombre' in df.columns:
        names_filtered = df['nombre'][(df['nombre'].notna()) & (df['nombre'] != "")]
        stats['nombre_total_cantidad'] = len(names_filtered)
        stats['nombre_cantidad_unica'] = names_filtered.nunique()
        stats['nombre_null_cantidad'] = df['nombre'].isnull().sum()
        stats['nombre_vacio_cantidad'] = (df['nombre'] == "").sum()
        if not names_filtered.empty:
            most_common_name = names_filtered.value_counts().idxmax()
            stats['nombre_mas_comun'] = most_common_name
            stats['nombre_mas_comun_cantidad'] = names_filtered.value_counts().iloc[0]
            # Estadísticas sobre extensiones
            extensions = names_filtered.str.extract(r'(\.\w+)$').fillna('')
            extension_counts = extensions[extensions != ""].squeeze().value_counts()
            ext_most_common = extension_counts.idxmax() if not extension_counts.empty else None
            stats['nombre_extension_mas_comun'] = ext_most_common
            stats['nombre_extension_cantidad_unica'] = extension_counts.nunique()
            # Longitud de nombres
            name_lengths = names_filtered.str.len()
            stats['nombre_longitud_media'] = name_lengths.mean()
            stats['nombre_longitud_min'] = name_lengths.min()
            stats['nombre_longitud_max'] = name_lengths.max()
        else:
            stats['nombre_mas_comun'] = None
            stats['nombre_mas_comun_cantidad'] = 0
            stats['nombre_extension_mas_comun'] = None
            stats['nombre_extension_cantidad_unica'] = 0
            stats['nombre_longitud_media'] = None
            stats['nombre_longitud_min'] = None
            stats['nombre_longitud_max'] = None

    # Estadísticas numéricas básicas
    numerical_fields = ['ancho', 'alto', 'peso']
    for field in numerical_fields:
        if field in df.columns:
            values = df[field].dropna()
            if not values.empty:
                stats[f'{field}_cantidad'] = len(values)
                stats[f'{field}_media'] = values.mean()
                stats[f'{field}_mediana'] = values.median()
                stats[f'{field}_desviacion_estandar'] = values.std()
                stats[f'{field}_min'] = values.min()
                stats[f'{field}_max'] = values.max()
                stats[f'{field}_q25'] = values.quantile(0.25)
                stats[f'{field}_q75'] = values.quantile(0.75)

    # Estadísticas de fechas
    for date_field in ['fecha_creacion', 'fecha_procesamiento']:
        if date_field in df.columns:
            dates = df[date_field].dropna()
            if not dates.empty:
                stats[f'{date_field}_mas_temprano'] = dates.min()
                stats[f'{date_field}_mas_tarde'] = dates.max()
                stats[f'{date_field}_ano_mas_comun'] = dates.dt.year.value_counts().idxmax()
                stats[f'{date_field}_mes_mas_comun'] = dates.dt.month.value_counts().idxmax()
                stats[f'{date_field}_fecha_media'] = pd.to_datetime(dates).mean()

    # Estadísticas catégoricas (ubicación)
    location_fields = ['barrio', 'calle', 'ciudad', 'cp', 'pais']
    for field in location_fields:
        if field in df.columns:
            values = df[field]
            filtered_values = values[(values.notna()) & (values != "")]
            stats[f'{field}_cantidad_unica'] = len(filtered_values)
            stats[f'{field}_null_cantidad'] = df[field].isnull().sum() + (df[field] == "").sum()
            if not filtered_values.empty:
                most_common = filtered_values.value_counts().idxmax()
                stats[f'{field}_mas_comun'] = most_common if most_common != "" else None
            else:
                stats[f'{field}_mas_comun'] = None
            stats[f'{field}_vacio_cantidad'] = (df[field] == "").sum()

    # objeto_procesado
    if 'objeto_procesado' in df.columns:
        processed_counts = df['objeto_procesado'].value_counts()
        stats['objeto_procesado_verdadero_cantidad'] = processed_counts.get(True, 0)
        stats['objeto_procesado_falso_cantidad'] = processed_counts.get(False, 0)

    # Estadísticas de arrays
    # objetos
    if 'objetos' in df.columns:
        all_objetos = [obj for sublist in df['objetos'].dropna() for obj in sublist]  # Aplanar lista
        objeto_counts = Counter(all_objetos)
        stats['objetos_total_unico'] = len(objeto_counts)
        stats['objetos_total_cantidad'] = sum(objeto_counts.values())
        stats['objetos_mas_comun'] = objeto_counts.most_common(1)[0] if objeto_counts else None
        # Estadísticas sobre longitudes de array
        array_lengths = df['objetos'].dropna().apply(len)
        stats['objetos_array_longitud_media'] = array_lengths.mean()
        stats['objetos_array_longitud_min'] = array_lengths.min()
        stats['objetos_array_longitud_max'] = array_lengths.max()

    # personas
    if 'personas' in df.columns:
        all_personas = [persona for sublist in df['personas'].dropna() for persona in sublist]
        persona_counts = Counter(all_personas)
        stats['personas_total_unico'] = len(persona_counts)
        stats['personas_total_cantidad'] = sum(persona_counts.values())
        stats['personas_mas_comun'] = persona_counts.most_common(1)[0] if persona_counts else None
        array_lengths = df['personas'].dropna().apply(len)
        stats['personas_array_longitud_media'] = array_lengths.mean() if not array_lengths.empty else 0
        stats['personas_array_longitud_min'] = array_lengths.min() if not array_lengths.empty else 0
        stats['personas_array_longitud_max'] = array_lengths.max() if not array_lengths.empty else 0

    # ruta_alternativa
    if 'ruta_alternativa' in df.columns:
        values = df['ruta_alternativa'].dropna()
        stats['ruta_alternativa_cantidad_unica'] = values.nunique()
        stats['ruta_alternativa_null_cantidad'] = df['ruta_alternativa'].isnull().sum()
        ruta_most_common = values.value_counts().idxmax() if not values.empty else None
        if ruta_most_common == "":
            ruta_most_common = None
        stats['ruta_alternativa_mas_comun'] = ruta_most_common

    # coordenadas
    if 'coordenadas' in df.columns:
        coords = df['coordenadas'].dropna()
        stats['coordenadas_no_null_cantidad'] = len(coords)
        stats['coordenadas_null_cantidad'] = df['coordenadas'].isnull().sum()
        # Asumiendo que son tipo dict o array [lat, lon], pero como en ejemplo es null, dejarlo así

    return stats

def print_statistics(stats, collection_name):
    """
    Imprime las estadísticas de forma legible con colores y estructura.
    """
    if colorama_available:
        init(autoreset=True)

    def print_colored(text, fore_color=None, style=None):
        if not colorama_available:
            print(text)
        else:
            output = ""
            if style:
                output += style
            if fore_color:
                output += fore_color
            print(f"{output}{text}")

    def print_group(title, keys):
        print_colored(f"\n{title}:", Fore.CYAN, Style.BRIGHT)
        for key in keys:
            if key in stats:
                print_colored(f"  {key}: {stats[key]}", Fore.WHITE, Style.NORMAL)

    print_colored(f"Estadísticas Matemáticas Completas de la Colección '{collection_name}'", Fore.GREEN, Style.BRIGHT)
    print_colored("=" * 80, Fore.YELLOW)

    # Grupos de estadísticas
    general = ['total_registros']
    nombre_stats = [k for k in stats if k.startswith('nombre_')]
    numericas = [k for k in stats if any(k.startswith(f'{f}_') for f in ['ancho', 'alto', 'peso'])]
    fechas = [k for k in stats if '_fecha' in k or 'ano' in k or 'mes' in k or k.endswith('_temprano') or k.endswith('_tarde')]
    ubicacion = [k for k in stats if any(k.startswith(f'{f}_') for f in ['barrio', 'calle', 'ciudad', 'cp', 'pais'])]
    processed = [k for k in stats if 'objeto_procesado' in k]
    arrays = [k for k in stats if 'objetos_' in k or 'personas_' in k]
    other = ['ruta_alternativa_cantidad_unica', 'ruta_alternativa_null_cantidad', 'ruta_alternativa_mas_comun', 'coordenadas_no_null_cantidad', 'coordenadas_null_cantidad']

    print_group("Estadísticas Generales", general)
    print_group("Estadísticas del Nombre", nombre_stats)
    print_group("Estadísticas Numéricas", numericas)
    print_group("Estadísticas de Fechas", fechas)
    print_group("Estadísticas de Ubicación", ubicacion)
    print_group("Procesamiento", processed)
    print_group("Arreglos y Listas", arrays)
    print_group("Otros", other)

    print_colored("\n" + "=" * 80, Fore.YELLOW)

def save_to_dat_file(stats, db_name, collection_name):
    """
    Guarda las estadísticas en un archivo .dat.
    """
    current_date = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f"{db_name}_{collection_name}_{current_date}.dat"
    try:
        with open(filename, 'w') as f:
            f.write(f"Estadísticas Matemáticas Completas de la Colección '{collection_name}'\n")
            f.write("=" * 80 + "\n")
            for key, value in stats.items():
                f.write(f"{key}: {value}\n")
            f.write("=" * 80 + "\n")
        print(f"Estadísticas guardadas en {filename}")
    except Exception as e:
        print(f"Error guardando archivo: {e}")

def main():
    """
    Función principal del script.
    """
    mongodb_uri = os.getenv('MONGODB_URI', 'mongodb://localhost:27017/')
    database_name = os.getenv('DATABASE_NAME', 'album')
    collection_name = os.getenv('COLLECTION_NAME', 'imagenes_2')

    collection = connect_to_mongodb()
    data = get_data(collection)
    df = convert_to_dataframe(data)
    stats = compute_statistics(df)
    print_statistics(stats, collection_name)
    save_to_dat_file(stats, database_name, collection_name)

if __name__ == "__main__":
    main()
