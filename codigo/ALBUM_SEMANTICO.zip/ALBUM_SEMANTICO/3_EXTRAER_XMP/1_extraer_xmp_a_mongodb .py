#!/usr/bin/env python3
"""
Script para extraer metadatos XMP específicos de imágenes almacenadas en MongoDB.
Extrae el valor correspondiente a la etiqueta ETIQUETA_XMP de todas las imágenes
en la colección target_collection de la base de datos your_database_name.
"""

import os
import json
import time
from pymongo import MongoClient
import pyexiv2

# Constante para la etiqueta XMP base a extraer
ETIQUETA_XMP_BASE = "Xmp.mwg-rs.Regions/mwg-rs:RegionList"

def conectar_mongodb(host='localhost', port=27017, db_name='your_database_name'):
    """Conecta a la base de datos MongoDB"""
    try:
        client = MongoClient(host, port)
        db = client[db_name]
        print(f"[✔] Conectado exitosamente a MongoDB: {db_name}")
        return db
    except Exception as e:
        print(f"[✘] Error conectando a MongoDB: {e}")
        return None

def obtener_rutas_imagenes(db):
    """Obtiene todas las rutas de imágenes de la colección target_collection"""
    try:
        collection = db['target_collection']
        cursor = collection.find({}, {'ruta': 1, '_id': 0})
        rutas = [doc['ruta'] for doc in cursor if 'ruta' in doc]
        print(f"[✔] Encontradas {len(rutas)} rutas de imágenes en la base de datos")
        return rutas
    except Exception as e:
        print(f"[✘] Error obteniendo rutas de imágenes: {e}")
        return []

def limpiar_valor_xmp(valor_completo):
    """Limpia el valor XMP para extraer solo el nombre limpio"""
    try:
        # El formato típico es: "<Xmp.mwg-rs.Regions/mwg-rs:RegionList[1]/mwg-rs:Name [Text] = Abuela Aurora>"
        # Necesitamos extraer todo lo que viene después del "="
        if "=" in valor_completo:
            partes = valor_completo.split("=", 1)
            if len(partes) == 2:
                valor = partes[1].strip()

                # Limpiar comillas y caracteres de cierre
                valor = valor.rstrip('>').strip()
                if valor.startswith('"') and valor.endswith('"'):
                    valor = valor[1:-1]
                elif valor.startswith("'") and valor.endswith("'"):
                    valor = valor[1:-1]

                return valor.strip()
        return None
    except Exception as e:
        print(f"[!] Error limpiando valor XMP: {e}")
        return None

def extraer_valores_etiquetas_xmp(imagen_path, etiqueta_base):
    """Extrae múltiples valores de etiquetas XMP de una imagen"""
    try:
        # Verificar si el archivo existe
        if not os.path.exists(imagen_path):
            print(f"[✘] Archivo no encontrado: {imagen_path}")
            return []

        print(f"[...] Procesando: {imagen_path}")

        # Leer metadatos usando pyexiv2
        metadata = pyexiv2.ImageMetadata(imagen_path)
        metadata.read()

        valores_encontrados = []
        indice = 1

        # Buscar todas las etiquetas numeradas
        while True:
            etiqueta_actual = etiqueta_base + f"[{indice}]/mwg-rs:Name"
            if etiqueta_actual in metadata:
                valor_completo = metadata[etiqueta_actual]
                print(f"[✔] Valor encontrado en {etiqueta_actual}: {valor_completo}")

                # Limpiar el valor extraído para obtener solo el nombre
                valor_limpio = limpiar_valor_xmp(str(valor_completo))
                if valor_limpio:
                    print(f"[✔] Valor limpio extraído: {valor_limpio}")
                    if valor_limpio not in valores_encontrados:  # Evitar duplicados internos
                        valores_encontrados.append(valor_limpio)
            else:
                break  # No hay más etiquetas numeradas

            indice += 1

        if not valores_encontrados:
            print(f"[!] Ninguna etiqueta XMP encontrada en {imagen_path}")

        return valores_encontrados

    except Exception as e:
        print(f"[✘] Error procesando {imagen_path}: {e}")
        return []

def main():
    """Función principal"""
    print("=== Extractor de XMP desde MongoDB ===")
    print(f"Etiqueta XMP base a extraer: {ETIQUETA_XMP_BASE}")
    print("=" * 50)

    # Conectar a MongoDB
    db = conectar_mongodb()
    if db is None:
        return

    # Obtener colección y rutas de imágenes
    collection = db['target_collection']
    rutas_imagenes = obtener_rutas_imagenes(db)
    if not rutas_imagenes:
        print("No se encontraron rutas de imágenes en la base de datos")
        return

    print(f"Procesando {len(rutas_imagenes)} imágenes...")
    print("-" * 50)

    # Contadores
    imagenes_procesadas = 0
    imagenes_con_valor = 0
    documentos_actualizados = 0
    valores_agregados = 0

    # Procesar cada imagen
    for ruta in rutas_imagenes:
        print(f"\nProcesando imagen {imagenes_procesadas + 1}/{len(rutas_imagenes)}:")

        # Extraer múltiples valores XMP
        valores_etiqueta = extraer_valores_etiquetas_xmp(ruta, ETIQUETA_XMP_BASE)

        if valores_etiqueta:
            imagenes_con_valor += 1

            # Mostrar los valores encontrados
            print("=" * 50)
            print(f"RUTA: {ruta}")
            print(f"VALORES ENCONTRADOS ({len(valores_etiqueta)}): {', '.join(valores_etiqueta)}")
            print("=" * 50)

            # Actualizar el documento en MongoDB siguiendo el flujo exacto solicitado
            try:
                # PASO 1: Primero, verificar y preparar el campo 'personas'
                doc = collection.find_one({"ruta": ruta})
                if doc:
                    # PASO 2: Verificar si campo 'personas' existe, sino crearlo vacío
                    if 'personas' not in doc or doc['personas'] is None:
                        lista_personas_actual = []
                        print(f"[i] Campo 'personas' no existe, inicializado vacío")
                    else:
                        if isinstance(doc['personas'], list):
                            lista_personas_actual = doc['personas'].copy()
                            print(f"[i] Campo 'personas' existe con {len(lista_personas_actual)} valores: {lista_personas_actual}")
                        else:
                            # Si no es lista, crear nueva lista vacía
                            lista_personas_actual = []
                            print(f"[i] Campo 'personas' existe pero no es lista, inicializado vacío")

                    # PASO 3: Procesar la imagen y extraer metadatos a otra lista
                    lista_valores_extraidos = valores_etiqueta.copy()
                    print(f"[i] Valores extraídos de XMP: {lista_valores_extraidos}")

                    # PASO 4: Comparar ambas listas y añadir solo valores nuevos
                    valores_a_anadir = []
                    for valor_extraido in lista_valores_extraidos:
                        if valor_extraido not in lista_personas_actual:
                            lista_personas_actual.append(valor_extraido)
                            valores_a_anadir.append(valor_extraido)

                    # PASO 5: Actualizar el campo personas solo si hay cambios
                    if valores_a_anadir:
                        print(f"[✔] Añadiendo valores nuevos: {valores_a_anadir}")
                        print(f"[✔] Campo 'personas' actualizado a: {lista_personas_actual}")

                        result = collection.update_one(
                            {"ruta": ruta},
                            {"$set": {"personas": lista_personas_actual}}
                        )

                        if result.modified_count > 0:
                            documentos_actualizados += 1
                            valores_agregados += len(valores_a_anadir)
                            print(f"[✔] Documento actualizado correctamente")
                        else:
                            print(f"[!] Error: No se pudo actualizar el documento")
                    else:
                        print(f"[i] No hay valores nuevos que añadir")
                        # Aun asi contamos la imagen como procesada

                else:
                    print(f"[!] Documento no encontrado para ruta: {ruta}")

            except Exception as e:
                print(f"[✘] Error actualizando documento para {ruta}: {e}")

        else:
            print(f"[!] No se encontraron valores para etiquetas XMP en: {ruta}")

        imagenes_procesadas += 1

    # Resumen final
    print("\n" + "=" * 60)
    print("=== RESUMEN DEL PROCESAMIENTO ===")
    print("=" * 60)
    print(f"Total de imágenes procesadas: {imagenes_procesadas}")
    print(f"Imágenes con valores en etiquetas: {imagenes_con_valor}")
    print(f"Imágenes sin valores en etiquetas: {imagenes_procesadas - imagenes_con_valor}")
    print(f"Documentos actualizados: {documentos_actualizados}")
    print(f"Valores agregados al campo 'personas': {valores_agregados}")

    print("\n" + "Procesamiento completado. Los documentos en MongoDB han sido actualizados con el campo 'personas'.")

if __name__ == "__main__":
    # Verificar dependencias
    try:
        import pymongo
        import pyexiv2
    except ImportError as e:
        print(f"[✘] Falta dependencia - {e}")
        print("Instala las dependencias con:")
        print("pip install pymongo pyexiv2")
        exit(1)

    main()
