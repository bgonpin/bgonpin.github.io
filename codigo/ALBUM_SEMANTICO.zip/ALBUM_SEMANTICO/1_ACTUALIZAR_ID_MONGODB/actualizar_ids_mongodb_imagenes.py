"""
Actualizar ID de MongoDB para Imágenes

Este script se conecta a una base de datos MongoDB y actualiza los documentos
en la colección especificada, utilizando hashes SHA-512 calculados a partir
de los archivos de imagen para establecer el campo _id y evitar duplicados.

Funcionalidades principales:
- Calcula el hash SHA-512 de archivos de imagen.
- Actualiza documentos en MongoDB si el hash no coincide con el _id actual.
- Maneja casos de duplicados para evitar eliminación de datos existentes.
- Imprime mensajes para archivos modificados.

Configuración requerida (puede personalizarse con variables de entorno):
- MONGO_URI: URI de conexión a MongoDB (por defecto: mongodb://localhost:27017).
- DB_NAME: Nombre de la base de datos (por defecto: "your_database_name").
- COLLECTION_NAME: Nombre de la colección (por defecto: "your_collection_name").

Notas:
- El campo "ruta" en cada documento debe contener la ruta completa al archivo de imagen.
- Solo procesa documentos donde la ruta existe y es accesible.
- Cierra la conexión a MongoDB al finalizar.
"""
import os
import hashlib
from pymongo import MongoClient

# --- CONFIGURACIÓN (Usar variables de entorno para personalización) ---
MONGO_URI = os.environ.get("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = os.environ.get("DB_NAME", "your_database_name")
COLLECTION_NAME = os.environ.get("COLLECTION_NAME", "your_collection_name")

def calcular_sha512(ruta):
    """Calcula el hash SHA-512 de un archivo dado"""
    sha512 = hashlib.sha512()
    with open(ruta, "rb") as f:
        for bloque in iter(lambda: f.read(4096), b""):
            sha512.update(bloque)
    return sha512.hexdigest()

def main():
    # Conexión a MongoDB
    cliente = MongoClient(MONGO_URI)
    db = cliente[DB_NAME]
    coleccion = db[COLLECTION_NAME]

    # Recorremos documentos
    for doc in coleccion.find({}):
        ruta = doc.get("ruta")
        if not ruta or not os.path.exists(ruta):
            continue

        # Calcular hash actual de la imagen
        hash_actual = calcular_sha512(ruta)

        # Verificar si está desactualizado
        if doc["_id"] != hash_actual or doc.get("hash") != hash_actual:
            # Chequear si ya existe un documento con _id = hash_actual
            existing = coleccion.find_one({"_id": hash_actual})
            if not existing:
                # Si no existe, insertar nuevo y eliminar viejo
                nuevo_doc = dict(doc)
                nuevo_doc["_id"] = hash_actual
                nuevo_doc["hash"] = hash_actual
                coleccion.insert_one(nuevo_doc)
                coleccion.delete_one({"_id": doc["_id"]})
                print(f"Archivo modificado: {ruta}")
            else:
                # Si existe, no hacer nada para evitar eliminación
                pass
        # Si no necesita actualización, no informa nada

    cliente.close()

if __name__ == "__main__":
    main()
