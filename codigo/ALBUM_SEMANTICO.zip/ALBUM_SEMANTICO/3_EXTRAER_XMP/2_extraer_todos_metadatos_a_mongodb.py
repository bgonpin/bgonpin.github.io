#!/usr/bin/env python3
"""
Script para extraer TODOS los metadatos XMP y EXIF de imágenes almacenadas en MongoDB.
Extrae todos los metadatos XMP y EXIF de todas las imágenes en la colección target_collection
de la base de datos your_database_name y los guarda en la colección target_metadata_collection.
"""

import os
import time
from pymongo import MongoClient
import pyexiv2

def conectar_mongodb(host='localhost', port=27017, db_name='your_database_name'):
    """Conecta a la base de datos MongoDB"""
    try:
        client = MongoClient(host, port)
        db = client[db_name]
        print(f"[✔] Conectado exitosamente a MongoDB: {db_name}")
        return db
    except Exception as e:
        print(f"[✘] Error conectando a MongoDB: {e}")
        return None

def obtener_rutas_imagenes(db):
    """Obtiene todas las rutas de imágenes de la colección target_collection"""
    try:
        collection = db['target_collection']
        cursor = collection.find({}, {'ruta': 1, '_id': 0})
        rutas = [doc['ruta'] for doc in cursor if 'ruta' in doc]
        print(f"[✔] Encontradas {len(rutas)} rutas de imágenes en la base de datos")
        return rutas
    except Exception as e:
        print(f"[✘] Error obteniendo rutas de imágenes: {e}")
        return []

def extraer_todos_metadatos(imagen_path):
    """Extrae todos los metadatos XMP y EXIF de una imagen"""
    try:
        # Verificar si el archivo existe
        if not os.path.exists(imagen_path):
            print(f"[✘] Archivo no encontrado: {imagen_path}")
            return {}

        print(f"[...] Procesando: {imagen_path}")

        # Leer metadatos usando pyexiv2
        metadata = pyexiv2.ImageMetadata(imagen_path)
        metadata.read()

        # Diccionario para almacenar todos los metadatos
        all_metadata = {}

        # Iterar sobre todos los metadatos disponibles
        for key in metadata:
            if key.startswith(('Xmp.', 'Exif.')):  # Extraer metadatos XMP y EXIF
                try:
                    valor = metadata[key]
                    # Convertir valor a string o mantener tipo original si es simple
                    if isinstance(valor, (int, float, str)):
                        valor_limpio = valor
                    else:
                        valor_limpio = str(valor)
                    all_metadata[key] = valor_limpio
                    print(f"[✔] Metadato encontrado: {key} = {valor_limpio}")
                except Exception as e:
                    print(f"[!] Error extrayendo {key}: {e}")
                    all_metadata[key] = f"Error: {str(e)}"

        if not all_metadata:
            print(f"[!] No se encontraron metadatos XMP o EXIF en {imagen_path}")

        return all_metadata

    except Exception as e:
        print(f"[✘] Error procesando {imagen_path}: {e}")
        return {}

def main():
    """Función principal"""
    print("=== Extractor de TODOS los metadatos XMP y EXIF desde MongoDB ===")
    print("Guardar en colección: target_metadata_collection")
    print("=" * 60)

    # Conectar a MongoDB
    db = conectar_mongodb()
    if db is None:
        return

    # Obtener colección fuente y rutas de imágenes
    collection_fuente = db['target_collection']
    rutas_imagenes = obtener_rutas_imagenes(db)
    if not rutas_imagenes:
        print("No se encontraron rutas de imágenes en la base de datos")
        return

    # Nueva colección para guardar todos los metadatos
    collection_metadatos = db['target_metadata_collection']

    print(f"Procesando {len(rutas_imagenes)} imágenes...")
    print("-" * 50)

    # Contadores
    imagenes_procesadas = 0
    imagenes_con_metadatos = 0
    documentos_insertados = 0

    # Procesar cada imagen
    for ruta in rutas_imagenes:
        print(f"\nProcesando imagen {imagenes_procesadas + 1}/{len(rutas_imagenes)}:")

        # Extraer todos los metadatos
        all_metadata = extraer_todos_metadatos(ruta)

        if all_metadata:
            imagenes_con_metadatos += 1

            # Mostrar los metadatos encontrados (resumido)
            print("=" * 60)
            print(f"RUTA: {ruta}")
            print(f"METADATOS ENCONTRADOS ({len(all_metadata)}):")
            for key, value in all_metadata.items():
                print(f"  {key}: {value}")
            print("=" * 60)

            # Verificar si ya existe un documento para esta imagen
            documento_existente = collection_metadatos.find_one({"ruta_imagen": ruta})

            # Preparar documento con metadatos como campos individuales
            documento_metadatos = {
                "ruta_imagen": ruta,
                "fecha_extraccion": time.strftime("%Y-%m-%d %H:%M:%S")
            }
            documento_metadatos.update(all_metadata)  # Agregar todos los metadatos como campos individuales

            if documento_existente:
                # Comparar los metadatos uno por uno para ver si han cambiado
                campos_han_cambiado = False

                # Crear diccionario con solo los cambios
                campos_actualizar = {
                    "fecha_extraccion": time.strftime("%Y-%m-%d %H:%M:%S")
                }

                for key, new_value in all_metadata.items():
                    existing_value = documento_existente.get(key)
                    if existing_value != new_value:
                        campos_han_cambiado = True
                        campos_actualizar[key] = new_value
                        print(f"[✔] Campo {key} cambiado de '{existing_value}' a '{new_value}'")

                if campos_han_cambiado:
                    print(f"[✔] Actualizando campos modificados para {ruta}")

                    # Actualizar el documento existente
                    try:
                        result = collection_metadatos.update_one(
                            {"ruta_imagen": ruta},
                            {"$set": campos_actualizar}
                        )

                        if result.modified_count > 0:
                            documentos_insertados += 1
                            print(f"[✔] Documento actualizado en target_metadata_collection")
                        else:
                            print(f"[!] Error: No se pudo actualizar el documento")
                    except Exception as e:
                        print(f"[✘] Error actualizando documento para {ruta}: {e}")
                else:
                    print(f"[i] Ningún campo ha cambiado para {ruta}, saltando actualización")
            else:
                # Insertar nuevo documento
                try:
                    result = collection_metadatos.insert_one(documento_metadatos)
                    if result.inserted_id:
                        documentos_insertados += 1
                        print(f"[✔] Documento insertado en target_metadata_collection con ID: {result.inserted_id}")
                    else:
                        print(f"[!] Error: No se pudo insertar el documento")
                except Exception as e:
                    print(f"[✘] Error insertando documento para {ruta}: {e}")

        else:
            print(f"[!] No se encontraron metadatos en: {ruta}")

        imagenes_procesadas += 1

    # Resumen final
    print("\n" + "=" * 60)
    print("=== RESUMEN DEL PROCESAMIENTO ===")
    print("=" * 60)
    print(f"Total de imágenes procesadas: {imagenes_procesadas}")
    print(f"Imágenes con metadatos: {imagenes_con_metadatos}")
    print(f"Imágenes sin metadatos: {imagenes_procesadas - imagenes_con_metadatos}")
    print(f"Documentos insertados en target_metadata_collection: {documentos_insertados}")

    print("\n" + "Procesamiento completado. Metadatos salvados en colección 'target_metadata_collection'.")

if __name__ == "__main__":
    # Verificar dependencias
    try:
        import pymongo
        import pyexiv2
    except ImportError as e:
        print(f"[✘] Falta dependencia - {e}")
        print("Instala las dependencias con:")
        print("pip install pymongo pyexiv2")
        exit(1)

    main()
